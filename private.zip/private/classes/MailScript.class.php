<?php
class MailScript extends DatabaseObject
{

}