
                </div> <!-- content-page -->

            </div> <!-- end wrapper-->
        </div>
        <!-- END Container -->        

        <!-- bundle -->
        <script src="<?php echo url_for('assets/js/vendor.min.js') ?> "></script>
        <script src="<?php echo url_for('assets/js/app.min.js') ?>"></script>

        <!-- Apex js -->
        <script src="<?php echo url_for('assets/js/vendor/apexcharts.min.js') ?>"></script>

        <!-- Todo js -->
        <script src="<?php echo url_for('assets/js/ui/component.todo.js') ?>"></script>

        <!-- demo app -->
        <script src="<?php echo url_for('assets/js/pages/demo.dashboard-crm.js') ?>"></script>
        <!-- end demo js-->
    </body>
</html>